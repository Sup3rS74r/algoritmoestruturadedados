import tkinter as tk
from tkinter import messagebox, Menu
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import queue

class Graph:
    def __init__(self):
        self.graph = nx.Graph()

    def add_node(self, node):
        self.graph.add_node(node)

    def add_edge(self, node1, node2):
        self.graph.add_edge(node1, node2)

    def remove_node(self, node):
        if node in self.graph:
            self.graph.remove_node(node)

    def remove_edge(self, node1, node2):
        if self.graph.has_edge(node1, node2):
            self.graph.remove_edge(node1, node2)

    def draw(self, canvas):
        plt.clf()
        pos = nx.spring_layout(self.graph)
        nx.draw(self.graph, pos, with_labels=True, node_color='lightblue', edge_color='gray', node_size=500, ax=canvas.figure.gca())
        canvas.draw()

class Stack:
    def __init__(self):
        self.stack = []

    def push(self, item):
        self.stack.append(item)

    def pop(self):
        if not self.is_empty():
            return self.stack.pop()
        else:
            return "Stack is empty"

    def is_empty(self):
        return len(self.stack) == 0

    def __str__(self):
        return str(self.stack)

class Queue:
    def __init__(self):
        self.queue = queue.Queue()

    def enqueue(self, item):
        self.queue.put(item)

    def dequeue(self):
        if not self.queue.empty():
            return self.queue.get()
        else:
            return "Queue is empty"

    def __str__(self):
        return str(list(self.queue.queue))

class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Graph Simulation")
        self.geometry("800x600")

        self.graph = Graph()
        self.stack = Stack()
        self.queue = Queue()

        self.create_widgets()
        self.create_menu()

    def create_widgets(self):
        self.node_frame = tk.Frame(self)
        self.node_frame.pack(pady=10)

        self.node_label = tk.Label(self.node_frame, text="Node:")
        self.node_label.pack(side=tk.LEFT)

        self.node_entry = tk.Entry(self.node_frame)
        self.node_entry.pack(side=tk.LEFT)

        self.add_node_button = tk.Button(self.node_frame, text="Add Node", command=self.add_node)
        self.add_node_button.pack(side=tk.LEFT)

        self.remove_node_button = tk.Button(self.node_frame, text="Remove Node", command=self.remove_node)
        self.remove_node_button.pack(side=tk.LEFT)

        self.edge_frame = tk.Frame(self)
        self.edge_frame.pack(pady=10)

        self.edge_label = tk.Label(self.edge_frame, text="Edge (Node1, Node2):")
        self.edge_label.pack(side=tk.LEFT)

        self.edge_entry = tk.Entry(self.edge_frame)
        self.edge_entry.pack(side=tk.LEFT)

        self.add_edge_button = tk.Button(self.edge_frame, text="Add Edge", command=self.add_edge)
        self.add_edge_button.pack(side=tk.LEFT)

        self.remove_edge_button = tk.Button(self.edge_frame, text="Remove Edge", command=self.remove_edge)
        self.remove_edge_button.pack(side=tk.LEFT)

        self.stack_frame = tk.Frame(self)
        self.stack_frame.pack(pady=10)

        self.stack_label = tk.Label(self.stack_frame, text="Stack Value:")
        self.stack_label.pack(side=tk.LEFT)

        self.stack_entry = tk.Entry(self.stack_frame)
        self.stack_entry.pack(side=tk.LEFT)

        self.push_stack_button = tk.Button(self.stack_frame, text="Push to Stack", command=self.push_stack)
        self.push_stack_button.pack(side=tk.LEFT)

        self.pop_stack_button = tk.Button(self.stack_frame, text="Pop from Stack", command=self.pop_stack)
        self.pop_stack_button.pack(side=tk.LEFT)

        self.queue_frame = tk.Frame(self)
        self.queue_frame.pack(pady=10)

        self.queue_label = tk.Label(self.queue_frame, text="Queue Value:")
        self.queue_label.pack(side=tk.LEFT)

        self.queue_entry = tk.Entry(self.queue_frame)
        self.queue_entry.pack(side=tk.LEFT)

        self.enqueue_button = tk.Button(self.queue_frame, text="Enqueue", command=self.enqueue)
        self.enqueue_button.pack(side=tk.LEFT)

        self.dequeue_button = tk.Button(self.queue_frame, text="Dequeue", command=self.dequeue)
        self.dequeue_button.pack(side=tk.LEFT)

        self.graph_frame = tk.Frame(self)
        self.graph_frame.pack(fill=tk.BOTH, expand=True)

        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvasTkAgg(self.figure, master=self.graph_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def create_menu(self):
        menubar = Menu(self)
        self.config(menu=menubar)

        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Show Graph", command=self.show_graph)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.quit)

        tools_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Tools", menu=tools_menu)
        tools_menu.add_command(label="Show Stack", command=self.show_stack)
        tools_menu.add_command(label="Show Queue", command=self.show_queue)

    def add_node(self):
        node = self.node_entry.get()
        if node:
            self.graph.add_node(node)
            self.node_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Node {node} added")
            self.graph.draw(self.canvas)

    def remove_node(self):
        node = self.node_entry.get()
        if node:
            self.graph.remove_node(node)
            self.node_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Node {node} removed")
            self.graph.draw(self.canvas)

    def add_edge(self):
        edge = self.edge_entry.get()
        if edge:
            node1, node2 = edge.split(",")
            node1, node2 = node1.strip(), node2.strip()
            self.graph.add_edge(node1, node2)
            self.edge_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Edge {node1} - {node2} added")
            self.graph.draw(self.canvas)

    def remove_edge(self):
        edge = self.edge_entry.get()
        if edge:
            node1, node2 = edge.split(",")
            node1, node2 = node1.strip(), node2.strip()
            self.graph.remove_edge(node1, node2)
            self.edge_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Edge {node1} - {node2} removed")
            self.graph.draw(self.canvas)

    def push_stack(self):
        value = self.stack_entry.get()
        if value:
            self.stack.push(value)
            self.stack_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Value {value} pushed to stack")

    def pop_stack(self):
        value = self.stack.pop()
        messagebox.showinfo("Success", f"Value {value} popped from stack")

    def enqueue(self):
        value = self.queue_entry.get()
        if value:
            self.queue.enqueue(value)
            self.queue_entry.delete(0, tk.END)
            messagebox.showinfo("Success", f"Value {value} enqueued")

    def dequeue(self):
        value = self.queue.dequeue()
        messagebox.showinfo("Success", f"Value {value} dequeued")

    def show_graph(self):
        self.graph.draw(self.canvas)

    def show_stack(self):
        stack_str = str(self.stack)
        self.display_text("Stack", stack_str)

    def show_queue(self):
        queue_str = str(self.queue)
        self.display_text("Queue", queue_str)

    def display_text(self, title, text):
        text_window = tk.Toplevel(self)
        text_window.title(title)
        text_window.geometry("300x200")
        text_label = tk.Label(text_window, text=text)
        text_label.pack(pady=10)

if __name__ == "__main__":
    app = Application()
    app.mainloop()
